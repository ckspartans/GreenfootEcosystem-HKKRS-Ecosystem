import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;

public class Mutate  
{
    int mutatedDna;
    
    private static double x;
    private static double a;
    private static double b;
    private static double c;
    private static boolean beneficial;
    
    private static Random random;
    
    //static boolean beneficial = true; //for future if we want to determine whether or not a mutation is benefitial or not//next iteration
    private static int[] importedDna; //in array to hold dna value of current organism
    

    /**
     * Constructor for objects of class Mutate
     */
 
    
    //Different functions for different organism due to different traits associated with each organism
    
    
    public static int[] mutateAlgae(int[] importedDna){ //etc, add more traits as we go on
       /*
        * ------Info for Imported Traits Based On Number in Array------
        * [0] = int associated with lifespan of the algae
        * [1] = int associated with the energy required to reproduce for the algae
        * [2] = int associated with the ability for an algae to defend itself
        */
       
       
       
       if (importedDna[0] < 2000){
           importedDna[0] += Greenfoot.getRandomNumber(200)-100;//test number to confirm mutation works and can modify values by given random number
       }
       if (importedDna[1] < 300){
           importedDna[1] += Greenfoot.getRandomNumber(10)-5;//test number to confirm mutation works and can modify values by given random number
       }
       
       return importedDna; //function sends back new modified algae dna values
    }
    
    
    
    
    private static boolean getRandomBoolean() {
        Random random = new Random();
        return random.nextBoolean();
    }
    
    
    
    
    public static int[] mutatePlantEater(int[] importedDna){ //etc, add mroe as needed
       /*
        * ------Info for Imported Traits Based On Number in Array------
        * [0] = int associated with speed of the plant eater
        * [1] = int associated with the range the plant eaters can see food
        * [2] = int associated with the energy required for the plant eater to reproduce
        * 
        * More will be added as development of program continues
        * 
        * 
        * 
        */
        

       if (importedDna[0] < 5){ //Mutates the speed as long as it remains under the threshold
          
          //variables associated with graph to ensure logical mutation of traits
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(30) - 15; //choses an x coordinate to use in relation to graph
          a = 1.2; 
          b = 1.5;
          c = 5;
          
          
          if(importedDna[0] + (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c) > 1){
              importedDna[0] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
          }
          
       }
       if(importedDna[1] < 200){ //Mutates the range a plant eater can see food as long as it remains under the threshold
          //GRAPH USED: https://www.desmos.com/calculator/gxengkp9b2
          
          //variables associated with graph to ensure logical mutation of traits
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.3; 
          b = 1.5;
          c = 19;
          
          //importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
          if(beneficial){
              importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else{
              if(((Math.pow(a,x))/(Math.pow(b,x) + a)) * c < importedDna[1]){
                  importedDna[1] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
                }
              if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[1]){ //if value wea re subtracting is bigger, then set trait value to 1
                  importedDna[1] = 1;
              }
          }
       }
       if(importedDna[2] > 200){ //Mutates the energy required to reproduce 
          //GRAPH USED: https://www.desmos.com/calculator/ug7pj240bd
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 26;
          
          //importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
          if(beneficial){
              importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[2]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[2] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[2] = 1;
          }
          
       }
       
       return importedDna; //function sends back new modified planteater dna values
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public static int[] mutateCarnivore(int[] importedDna){ //etc, add mroe as needed
       
        
       /*
        * ------Info for Imported Traits Based On Number in Array------
        * [0] = int associated with speed of the carnivore
        * [1] = int associated with the range the carnivore can see food
        * [2] = int associated with the energy required for the carnivore to reproduce
        * [3] = int associated with the level of defense the carnivore has
        * [4] = int associated with the level of attack the carnivore has
        */
        

       if (importedDna[0] < 6){ //Mutates the speed as long as it remains under the threshold
          //GRAPH USED: https://www.desmos.com/calculator/fxarjqw95l
          
          //variables associated with graph to ensure logical mutation of traits
          x = Greenfoot.getRandomNumber(30) - 15; //choses an x coordinate to use in relation to graph
          a = 1.2; 
          b = 1.5;
          c = 5;
          
          if(importedDna[0] + (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c) > 1){
              importedDna[0] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //creates a new
          }
          
       }
       if(importedDna[1] < 300){ //Mutates the range a plant eater can see food as long as it remains under the threshold
          //GRAPH USED: https://www.desmos.com/calculator/gxengkp9b2
          
          //variables associated with graph to ensure logical mutation of traits
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2; 
          b = 1.5;
          c = 47;
          
          //importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //creates a new
          if(beneficial){
              importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[1]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[1] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[1] = 1;
          }
          
       }
       if(importedDna[2] > 200){ //Mutates the energy required to reproduce 
          //GRAPH USED: https://www.desmos.com/calculator/ug7pj240bd
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 26;
          
          //importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[2]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[2] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[2] = 1;
          }
          
       }
       if(importedDna[3] > 45){ //Mutates the value to defend itself
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[3]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[3] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[3] = 1;
          }
          
       }
       if(importedDna[4] > 50){ //Mutates the value of to attack
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[4] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[4] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[4]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[4] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[4] = 1;
          }
          
       }
       
       return importedDna; //function sends back new modified planteater dna values
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    public static int[] mutateOmnivore(int[] importedDna){ //etc, add mroe as needed
       
        
       /*
        * ------Info for Imported Traits Based On Number in Array------
        * [0] = int associated with speed of the omnivore
        * [1] = int associated with the range the omnivore can see food
        * [2] = int associated with the energy required for the omnivore to reproduce
        * [3] = int associated with the health of the omnivore
        * [4] = int associated with the level of defense the omnivore has
        * [5] = int associated with the level of attack the omnivore has
        */
        

       if (importedDna[0] < 6){ //Mutates the speed as long as it remains under the threshold
          //GRAPH USED: https://www.desmos.com/calculator/fxarjqw95l
          
          //variables associated with graph to ensure logical mutation of traits
          x = Greenfoot.getRandomNumber(30) - 15; //choses an x coordinate to use in relation to graph
          a = 1.2; 
          b = 1.5;
          c = 5;
          
          if(importedDna[0] + (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c) >= 1){
              importedDna[0] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //creates a new
          }
          
       }
       if(importedDna[1] < 300){ //Mutates the range a plant eater can see food as long as it remains under the threshold
          //GRAPH USED: https://www.desmos.com/calculator/gxengkp9b2
          
          //variables associated with graph to ensure logical mutation of traits
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2; 
          b = 1.5;
          c = 47;
          
          //importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //creates a new
          if(beneficial){
              importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[1]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[1] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[1] = 1;
          }
          
       }
       if(importedDna[2] > 200){ //Mutates the energy required to reproduce 
          //GRAPH USED: https://www.desmos.com/calculator/ug7pj240bd
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 26;
          
          //importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[2]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[2] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[2] = 1;
          }
          
       }
       if(importedDna[3] < 200){ //Mutates the value to defend itself
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[3]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[3] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[3] = 1;
          }
          
       }
       if(importedDna[4] < 45){ //Mutates the value to defend itself
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[4] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[4]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[4] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[4] = 1;
          }
          
       }
       if(importedDna[5] < 50){ //Mutates the value of to attack
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[4] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[5] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[5]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[5] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[5] = 1;
          }
          
       }
       
       return importedDna; //function sends back new modified planteater dna values
    }
    
    
    
    
    
    
    public static int[] mutateScavenger(int[] importedDna){ //etc, add mroe as needed
       
        
       /*
        * ------Info for Imported Traits Based On Number in Array------
        * [0] = int associated with speed of the scavenger
        * [1] = int associated with the range the scavenger can see food
        * [2] = int associated with the energy required for the scavenger to reproduce
        * [3] = int associated with the health of the scavenger
        * [4] = int associated with the level of defense the scavenger has
        * [5] = int associated with the level of attack the scavenger has
        */
        

       if (importedDna[0] < 6){ //Mutates the speed as long as it remains under the threshold
          //GRAPH USED: https://www.desmos.com/calculator/fxarjqw95l
          
          //variables associated with graph to ensure logical mutation of traits
          x = Greenfoot.getRandomNumber(30) - 15; //choses an x coordinate to use in relation to graph
          a = 1.2; 
          b = 1.5;
          c = 5;
          
          if(importedDna[0] + (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c) >= 1){
              importedDna[0] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //creates a new
          }
          
       }
       if(importedDna[1] < 300){ //Mutates the range a plant eater can see food as long as it remains under the threshold
          //GRAPH USED: https://www.desmos.com/calculator/gxengkp9b2
          
          //variables associated with graph to ensure logical mutation of traits
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2; 
          b = 1.5;
          c = 47;
          
          //importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //creates a new
          if(beneficial){
              importedDna[1] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[1]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[1] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[1] = 1;
          }
          
       }
       if(importedDna[2] > 200){ //Mutates the energy required to reproduce 
          //GRAPH USED: https://www.desmos.com/calculator/ug7pj240bd
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 26;
          
          //importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[2] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[2]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[2] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[2] = 1;
          }
          
       }
       if(importedDna[3] < 150){ //Mutates the value to defend itself
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[3]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[3] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[3] = 1;
          }
          
       }
       if(importedDna[4] < 45){ //Mutates the value to defend itself
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[3] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[4] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[4]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[4] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[4] = 1;
          }
          
       }
       if(importedDna[5] < 50){ //Mutates the value of to attack
          //GRAPH USED: https://www.desmos.com/calculator/1zgotjvzib
          
          //variables associated with graph to ensure logical mutation of traits 
          beneficial = getRandomBoolean();
          
          x = Greenfoot.getRandomNumber(50) - 25; //choses an x coordinate to use in relation to graph
          a = 1.2;
          b = 1.5;
          c = 22;
          
          //importedDna[4] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; 
          if(beneficial){
              importedDna[5] += ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //sets new DNA
              
          } else if (((Math.pow(a,x))/(Math.pow(b,x) + a)) * c > importedDna[5]){ //if the value we are subtracting is smaller then the value of the trait
              importedDna[5] -= ((Math.pow(a,x))/(Math.pow(b,x) + a)) * c; //subtract value from trait
          } else{ //if value wea re subtracting is bigger, then set trait value to 1
              importedDna[5] = 1;
          }
          
       }
       
       return importedDna; //function sends back new modified planteater dna values
    }
}


/*
 * -----Notes-----
 * Add a greenfoot.getRandomNumber(2); to get a 1 or 2 to determine whether a mutation is beneficial. (1 = beneficial, 2 = non-beneficial)
 * 
 * Add if statements to check if mutation is detrimental, the trait doesnt become negative --> HOWEVER if we were to let it become negative, organism dies?
 * 
 * 
 * Make traits influence other traits:
 * 
 * SPEED --> affects DEF and ATT
 * HEALTH --> affects reproduce energy
 */
