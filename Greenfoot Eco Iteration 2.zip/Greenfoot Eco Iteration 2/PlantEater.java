import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
//import java.awt.*;
/**
 * Write a description of class TestOrganism here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class PlantEater extends AbstOrganism
{
    //initialize dna variable
    int []newDna;
    //initialize algae for target array
    public ArrayList <Algae> target;
    //initialize carnivore predator array
    public ArrayList <Carnivore> pred;
    //initialize omnivore predator array
    public ArrayList <Omnivore> pred2;
    //initialize algae 
    public Algae alg = new Algae();
    //initialize nearestTarget
    public Actor nearestTarg;
    //initialize Ai
    public AI ai = new AI();
    //initialize corpse
    Corpse corp = new Corpse();
    //set border color
    Color edge = new Color(0,0,0);
    //set fill color
    Color fill = new Color(50,50,250);
    //set feed boolean
    boolean f = true; 
    public PlantEater(){
        //set up mutate variable with desired components
        newDna = new int[]{(int)this.speed,(int)this.sight,(int)this.repro_energy};
        //call mutate for planteater
        Mutate.mutatePlantEater(newDna);
        //set the lifespan for a random number within 2900 frames
        lifespan = Greenfoot.getRandomNumber(900)+2000;
        //set starting age to 0
        age = 0;
        //minimum required energy for reproduction
        repro_energy = 100;
        //set starting speed
        speed = 1;
        //set stating sight
        sight = 30;
        //set starting health
        health = 100;
        //set starting energy
        energy = 35.0;
        //set att and def
        att = 5;
        def = 5;
        //initialze world
        MyWorld world = (MyWorld) getWorld();

    }
    public void getImage(int siz){
        //set starting size for image
        GreenfootImage img = new GreenfootImage(siz,siz);
        //set the border color and size
        img.setColor(edge);
        img.fillOval(0-1,0-1,siz-9,siz-9);
        //set the inside color and size
        img.setColor(fill);
        img.fillOval(0,0,siz-11,siz-11);
        //draw the variable
        setImage(img);
    }
    /**
     * Act - do whatever the TestOrganism wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //if health is too low, then die and add a corpse
        if (health <= 0){
            world.addObject(corp, getX(), getY());
            die();
            
        }
        //if world doesnt exist, set world to my world
        if(world == null){
            world = (MyWorld) getWorld();
        }
        //set target as algae
        target = (ArrayList) getWorld().getObjects(Algae.class);
        //set predator as carnivore
        pred = (ArrayList) getWorld().getObjects(Carnivore.class);
        //set second predator as omnivore
        pred2 = (ArrayList) getWorld().getObjects(Omnivore.class);
        //if there's an algae in range then track, else turn and move
        if (target.size() >0 && target != null  ){ 
            ai.trk(this, target,speed, sight);
        }else{
            setRotation(getRotation()+Greenfoot.getRandomNumber(40)-20);
            move(1);
        }
        //if theres a predator then flee
        if (pred.size()>0 && pred != null && f){
            ai.flee(this, pred, speed, sight);
        }
        //if theres a predator then flee
        if(pred2.size()>0 && pred2 != null && f){
            ai.flee(this, pred2, speed, sight);
        }
        //if theres nothing then turn and move
        if(f==false){
            setRotation(getRotation()+Greenfoot.getRandomNumber(40)-20);
            move(1);
        }
        //run grow
        grow();
        //run feed
        feed();
        //run age
        age();
        //run reproduce
        reproduce();

    }
    public void feed(){
        for(int i = 0; i <target.size(); i++){
            if(MyWorld.getDist(this, target.get(i))<10){//if touching the Algae
                energy += alg.energy*0.09;// take its energy
                lifeforms.remove(Algae.class);//remove it from lifeforms
                removeTouching(Algae.class);  //remove it from the world             
                target.remove(i);//remove it from the target array
                target = (ArrayList) getWorld().getObjects(Algae.class);//reset the array
            }
        }
    }


    public void age(){
        // increase the age and decrease the energy
        age ++;
        energy -= 0.01;
        if (energy >= 10 || health >= 20){ // if not hungry, go at regular speed, go faster
            speed = newDna[0];
            if (speed <1){
                speed ++;
            }
        }else{
            speed = newDna[0]+2;
        }
        //and check to see if age past lifespan and energy is high enough
        if(age>= lifespan || energy <= 20){ //if it isnt, then die and add a corpse
            world.addObject(corp, getX(), getY());
             die();
        }
       
    }
    public void mutate(){
        //set new Dna
        newDna = new int[]{(int)this.speed,(int)this.sight,(int)this.repro_energy};
        //mutate with new Dna
        Mutate.mutatePlantEater(newDna);
        
    }
    public void reproduce(){
        int numKids = 2; //set a random number of children
       
            if(energy>repro_energy){//when energy is bigger than required reproduction energy
               
                for(int i =0; i<numKids; i++){ //make a number of tempkids
                PlantEater tempKidP = new PlantEater();  //set algae to tempKid
                mutate();
                tempKidP.speed = newDna[0];
                tempKidP.sight = newDna[1];
                tempKidP.repro_energy = newDna[2];
                world.addObject(tempKidP,getX(),getY()); //spawn a new tempKid
                lifeforms.add(tempKidP); //add the new kid to the lifeforms array
                tempKidP.turn(Greenfoot.getRandomNumber(359)+1);   //make it turn once it respawns
                tempKidP.move(Greenfoot.getRandomNumber(90)+20);     //make it move in the previous direction
            }
            world.addObject(corp, getX(), getY()); //add a corpse then die
            die();
        }
    }
   public void grow(){//growth function
        if (siz <= 25){//until size  = 25
            //set size to 20% of energy plus 10
            siz = (int)(0.2*energy+15.);
        }
        //set image siz
        getImage(siz);
    }
}