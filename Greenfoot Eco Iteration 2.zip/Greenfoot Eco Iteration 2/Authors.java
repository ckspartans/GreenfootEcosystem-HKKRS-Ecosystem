import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Authors here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Authors extends AbstButton
{
    // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
    public Authors(){
        super("BY: Ryan, Keagan, Sam, Hector, Karthik", 25);
    }
    
    public void onClick(){
       // world.addObject(new Algae(), Greenfoot.getRandomNumber(world.getWidth()), Greenfoot.getRandomNumber(world.getHeight()));
    }
}
