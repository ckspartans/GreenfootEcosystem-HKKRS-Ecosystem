import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
//import java.awt.*;
/**
 * Write a description of class TestOrganism here.
 * 
 * @author Hector Salermo 
 * @version (a version number or a date)
 */
public class Scavenger extends AbstOrganism
{   
    //initialize the newDna
    int []newDna;
    // array for target of the scavenger
    public ArrayList <Corpse> target;
    // arraylist of predators
    public ArrayList <Carnivore> pred;
     //initialize omnivore predator array
    public ArrayList <Omnivore> pred2;
    //boolean to check whether it's tracking or not
    public boolean tracking = false; 
    // actor call for the nearest Target
    public Actor nearestTarg; 
    // initialize the ai class
    public AI ai = new AI(); 
    //initialize the Algae class
    Algae alg = new Algae(); 
    //call the corpse class
    Corpse corp = new Corpse(); 
    //set the color of the borders for the image
    Color edge = new Color(0,0,0); 
    // set the color for itself
    Color fill = new Color(250,250,0); 
    public Scavenger(){

        //set up mutate variable with desired components
        newDna = new int[]{(int)this.speed,(int)this.sight,(int)this.repro_energy,(int)health, att, def}; 
        //call mutate for scavenger
        Mutate.mutateScavenger(newDna); 
        //set the lifespan for a random number within 2900 frames
        lifespan = Greenfoot.getRandomNumber(900)+2000; 
        //set starting age to 0
        age = 0; 
        //minimum required energy for reproduction
        repro_energy = 75;
        //set starting speed
        speed = 1;
        //set sight variable
        sight = 80;
        //set starting health
        health = 50;
        //set starting energy
        energy = 10;
        //set starting attack and defense
        att = 5;
        def = 5;
        //initialize world
        MyWorld world = (MyWorld) getWorld();
        //set starting energy
        energy = 35.0;

    }
    public void getImage(int siz){
        //set starting size for image
        GreenfootImage img = new GreenfootImage(siz,siz);
        //set the border color and size
        img.setColor(edge);
        img.fillOval(0-1,0-1,siz-9,siz-9);
        //set the inside color and size
        img.setColor(fill);
        img.fillOval(0,0,siz-11,siz-11);
        //draw the variable
        setImage(img);
    }
    //boolean target = false;

    public void act() 
    {
        //if health is less than 0, run die function
        if (health <= 0){
            world.addObject(corp, getX(), getY());
            die();
            
        }
        //if the world isn't initialized, initialize it
        if(world == null){
            world = (MyWorld) getWorld();
        }
        //set the targets to Corpses
        target = (ArrayList) getWorld().getObjects(Corpse.class);
        //set the predators to Carnivores
        pred = (ArrayList) getWorld().getObjects(Carnivore.class);
         //set second predator as omnivore
        pred2 = (ArrayList) getWorld().getObjects(Omnivore.class);
        //if there is a target, run track function
        if (target.size() >0 && target != null  ){
            ai.trk(this, target,speed, sight);
        }//else turn and move 
        else{
            setRotation(getRotation()+Greenfoot.getRandomNumber(40)-20);
            move(1);
        }
        //if there is a predator, run flee function
        if (pred.size()>0 && pred != null){
            ai.flee(this, pred, speed, sight);
        }
        if(pred2.size()>0 && pred2 != null && f){
            ai.flee(this, pred2, speed, sight);
        }//else turn and move
        else{
            
            setRotation(getRotation()+Greenfoot.getRandomNumber(40)-20);
            move(1);
            
        }
        // run grow function
        grow();
        //run feed function
        feed();
        //run age function
        age();
        //run reproduce function
        reproduce();

    }    
    
    public void feed(){
         //as long as there is a target, run this for loop
        for(int i = 0; i <target.size(); i++){
            //if the distance is small enough, run this
            if(MyWorld.getDist(this, target.get(i))<10){
                //add the corpse energy
                energy += alg.energy*0.09;
                //remove the object from lifeforms array
                lifeforms.remove(Corpse.class);
                //remove the object from the world
                removeTouching(Corpse.class);
                //remove the object from the target's list
                target.remove(i);
                //reset the target arraylist
                target = (ArrayList) getWorld().getObjects(Corpse.class);
            }
        }
    }
    public void move(){
        
    }

    public void age(){
        //add age
        age ++;
        //reduce energy
        energy -= 0.01;

        // if hungry, go faster
        if (energy >= 10){ 
            speed = newDna[0];
            
        }else{
            speed = newDna[0]+2;
        }
        //and check to see if age is past lifespan
        if(age>= lifespan){
            //if it is past lifespan, kill it and add a corpse
            world.addObject(corp, getX(), getY());
             die();
        }
       
    }
    public void mutate(){
        //set new Dna
        newDna = new int[]{(int)this.speed,(int)this.sight,(int)this.repro_energy,(int)health, att, def};
        //mutate with new Dna
        Mutate.mutateScavenger(newDna);
        
    }
    public void reproduce(){
        int numKids = 2; //set a random number of children
       
            if(energy>repro_energy){//when energy is bigger than required reproduction energy
               
                for(int i =0; i<numKids; i++){ //make a number of tempkids
                //initialize a scavenger as tempKid
                Scavenger tempKidP = new Scavenger();  
                // call mutate
                mutate();
                //set parameters from mutate
                tempKidP.speed = newDna[0];
                tempKidP.sight = newDna[1];
                tempKidP.repro_energy = newDna[2];
                tempKidP.health = newDna[3];
                tempKidP.att = newDna[4];
                tempKidP.def = newDna[5];
                // add the child to the world
                world.addObject(tempKidP,getX(),getY()); 
                //add the new kid to the lifeforms array
                lifeforms.add(tempKidP); 
                 //make it turn once it respawns
                tempKidP.turn(Greenfoot.getRandomNumber(359)+1);
                 //make it move in the previous direction
                tempKidP.move(Greenfoot.getRandomNumber(90)+20);    
            }
            //once reproduce has been run, kill it and add a corpse
            world.addObject(corp, getX(), getY());
            die();
        }
    }
    public void grow(){//growth function
        if (siz <= 25){//until size  = 25
            //set size to 20% of energy plus 10
            siz = (int)(0.2*energy+10.);
        }
        //set image siz
        getImage(siz);
    }
}