
//import java.awt.*;
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class PlantGrass here.
 * 
 * @author Hector Salermo  
 * @version (a version number or a date)
 */
public class Corpse extends AbstOrganism
{
    //initialize the newDna
    int [] newDna;
    //set the color of the borders for the image
    Color edge = new Color(0,0,0); 
    // set the color for itself
    Color fill = new Color(130,62,15);
    
    
    public  Corpse(){
        //set starting age to 0
        age = 0;
        //minimum required energy for reproduction        
        repro_energy = 100;
        //set the lifespan for a random number within 1800 frames
        lifespan = Greenfoot.getRandomNumber(900)+900;
        //set health
        health = 100;
        //set starting energy
        energy = 70;
        //set starting size
        siz = (int)(0.2*energy+10.);
        //set att and def to 0
        att = 0;
        def = 0;
        //get image with size variable
        getImage(siz);
        //initialize MyWorld
        MyWorld world;
        
           
    }
    
    /**
     * Act - do whatever the Corpse wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // if world isnt initialized
        if(world == null){
            world = (MyWorld) getWorld();
        } 
        //run grow
        grow();
        //run age
        age();

    }    
    
    public void feed(){
     
    }

    public void grow(){
        //increase size based on the current energy
        if ( siz <= 100){
            siz = (int)(0.2*energy+10.);
        }
        getImage(siz);
        
        //say("Grow not implemented");
    }
    public void getImage(int siz){
        //set image parameters
        GreenfootImage img = new GreenfootImage(siz,siz);
        //set the border color and size
        img.setColor(edge);
        img.fillOval(0-1,0-1,siz-9,siz-9);
        //set the inside color and size
        img.setColor(fill);
        img.fillOval(0,0,siz-11,siz-11);
        //draw the variable
        setImage(img);
    }
    public void reproduce(){

        //say("Reproduce not implemented");
    }

    public void age(){
        //increase age and decrease energy
        energy -= 0.1;
        age ++;

        //and check to see if past lifespan or a certain limit of energy
        if(age>= lifespan || energy <= 10){// they will  die if they ve lived from 900 to 1800 frames or runs out of energy
             die();
        }
            
        //say("Age not implemented");
    }
    
    public void mutate(){

    }
}
