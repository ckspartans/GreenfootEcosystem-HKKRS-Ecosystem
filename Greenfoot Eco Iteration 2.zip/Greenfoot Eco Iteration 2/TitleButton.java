import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TitleButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TitleButton extends AbstButton
{
    // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
    public TitleButton(){
        super("ABSTORGANISMS - CLICK TO START", 50);
    }
    
    public void onClick(){
       // world.addObject(new Algae(), Greenfoot.getRandomNumber(world.getWidth()), Greenfoot.getRandomNumber(world.getHeight()));
    }
}
