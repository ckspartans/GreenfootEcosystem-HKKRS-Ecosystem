import greenfoot.*;
import java.util.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    IntroScreen intro;
    Algae alg;
    PlantEater pe;
    Carnivore carn;
    Scavenger scav;
    Omnivore omni;
    //PlantEater pe;
    int foodEaten = 0;
    int spawnTimer = 100;
    int numGrass = 0;
    int maxX = 800;
    int maxY = 700;
    int y = 100;
    boolean p = false;
    String [] names = new String[] {"Algae", "Herbivore", "Carnivore", "Scavenger", "Omnivore"};
    ArrayList <Buttons> myButtons = new ArrayList <Buttons>();
    boolean music = false;
    GreenfootSound backgroundMusic = new GreenfootSound("benny-hill-theme.mp3");
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 800, 1); //reference from World
        intro = new IntroScreen(this); //start with Intro screen
        AbstOrganism.lifeforms = new ArrayList(); //initialize the lifeforms arraylist
        
     
        Algae alg = new Algae(); //initialize algae
        PlantEater pe = new PlantEater(); //initialize algae
        Carnivore carn = new Carnivore(); //initialize algae
        Scavenger scav = new Scavenger(); //initialize algae
        Omnivore omni = new Omnivore(); //initialize algae
        
        addObject(carn, Greenfoot.getRandomNumber(maxX), Greenfoot.getRandomNumber(maxY)); //add the Algae to a random location on the screen within boundaries
        for(int i = 0; i < 5; i ++){
           addObject(new Algae(), Greenfoot.getRandomNumber(maxX), Greenfoot.getRandomNumber(maxY)); //add the Algae to a random location on the screen within boundaries
        }
        for(int i = 0; i < 3; i ++){
           addObject(new PlantEater(), Greenfoot.getRandomNumber(maxX), Greenfoot.getRandomNumber(maxY)); //add the Algae to a random location on the screen within boundaries
        }
        for(int i = 0; i < 2; i ++){
           addObject(new Omnivore(), Greenfoot.getRandomNumber(maxX), Greenfoot.getRandomNumber(maxY)); //add the Algae to a random location on the screen within boundaries
        }
        for(int i = 0; i < 3; i ++){
           addObject(new Scavenger(), Greenfoot.getRandomNumber(maxX), Greenfoot.getRandomNumber(maxY)); //add the Algae to a random location on the screen within boundaries
        }
       

        Greenfoot.setWorld(intro); //set the start screen
        for(int i = 0; i < names.length; i ++){
            addObject(new Buttons(names[i], myButtons), 870,y); //add the button that spawns Algae to the world
            y += 50;
        }
    }

    
    public void act(){
        if(music){
            backgroundMusic.playLoop();
        }
    }
    
    public static float getDist(Actor a, Actor b){
        double dist;
        double xLength = a.getX() - b.getX();
        double yLength = a.getY() - b.getY();
        dist = Math.sqrt(Math.pow(xLength, 2) + Math.pow(yLength, 2));
        return (float)dist;
    }
        public static float getDist(int a, int b){
        double dist;
        double xLength = a - b;
        double yLength = a - b;
        dist = Math.sqrt(Math.pow(xLength, 2) + Math.pow(yLength, 2));
        return (float)dist;
    }
}