import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class AbstOrganism here.
 * 
 * @author Rowbottom 
 * @version Sept. 27 2017
 */
public abstract class AbstOrganism extends Actor{

    static public ArrayList <Actor> lifeforms = new ArrayList<Actor>();//list of all the organsims in the game
    public int age;
    public int lifespan;
    public double repro_energy;
    public int siz;
    public int sight;
    static public GreenfootImage [] imgs; //animation capabilities
    public double health;
    public double energy;
    public int speed;
    public int att;
    public int def;
    
    public boolean f;
    MyWorld world;
       
    public abstract void feed();
    
    public abstract void grow();
    
    public abstract void reproduce();
    
    public abstract void age();
    
        public void die(){
        //initialize corpse//remove them from all lists
        lifeforms.remove(this);
        if(this != null){//if object still exists, then remove it
            //remove them from the world
            world.removeObject(this);
        }
    }
    public abstract void mutate();  
    
    public void say(String phrase){
        System.out.println(phrase);
    }
    
}
