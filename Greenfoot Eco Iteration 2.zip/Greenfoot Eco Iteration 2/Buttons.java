import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class AButton here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Buttons extends AbstButton
{
    MyWorld world;
    MouseInfo mouse = Greenfoot.getMouseInfo();
    public static boolean mouseDragEnded;
    ArrayList<Buttons> buttons;
    int index = -1;
    public Buttons(){
        super("", 30);
    }
    
    public Buttons(String myType, ArrayList<Buttons> b){
        super(myType, 30);
        buttons = b;
        buttons.add(this);
        index = buttons.size()-1;
        
    }
    
    public void act(){
        if (world == null){
            world = (MyWorld)getWorld();
        }
        if (Greenfoot.mouseClicked(this)){
            onClick();
        }
    }
    
    public void onClick(){
        //add ifs for each constructor
        if(this.index == 0){
            world.addObject(new Algae(), Greenfoot.getRandomNumber(world.getWidth()), Greenfoot.getRandomNumber(world.getHeight()));
            AbstOrganism.lifeforms.add(this);
        }else if(this.index == 1){
            world.addObject(new PlantEater(), Greenfoot.getRandomNumber(world.getWidth()), Greenfoot.getRandomNumber(world.getHeight()));
            AbstOrganism.lifeforms.add(this);            
        }else if(this.index == 2){
            world.addObject(new Carnivore(), Greenfoot.getRandomNumber(world.getWidth()), Greenfoot.getRandomNumber(world.getHeight()));
            AbstOrganism.lifeforms.add(this);
        }else if(this.index == 3){
            world.addObject(new Scavenger(), Greenfoot.getRandomNumber(world.getWidth()), Greenfoot.getRandomNumber(world.getHeight()));
            AbstOrganism.lifeforms.add(this);
        }else if(this.index == 4){
            world.addObject(new Omnivore(), Greenfoot.getRandomNumber(world.getWidth()), Greenfoot.getRandomNumber(world.getHeight()));
            AbstOrganism.lifeforms.add(this);
        }
        //System.out.println(index);
    }
        public void dragged(){
        //add ifs for each constructor
        if(this.index == 0){
            if(mouseDragEnded == true){
               world.addObject(new Algae(), mouse.getX(), mouse.getY());
            }
        }
        else if(this.index == 1){
            if(mouseDragEnded == true){
               world.addObject(new PlantEater(), mouse.getX(), mouse.getY());
            }
        }else if(this.index == 2){
            if(mouseDragEnded == true){
               world.addObject(new Carnivore(), mouse.getX(), mouse.getY());
            }
        }
        //System.out.println(index);
    }  
}