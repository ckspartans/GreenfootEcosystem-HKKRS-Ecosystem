
//import java.awt.*;
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
/**
 * Write a description of class PlantGrass here.
 * 
 * @author Hector Salermo 
 * @version (a version number or a date)
 */
public class Algae extends AbstOrganism
{
    //initialize the newDna
    int [] newDna;
    //set the color of the borders for the image
    Color edge = new Color(0,0,0); 
    // set the color for itself
    Color fill = new Color(50,250,50);
    //call the corpse class
    Corpse corp = new Corpse();
    //number of Algae in the world
    int algAmount = 0;
    public Algae(){
        //set starting age to 0
        age = 0;
        //minimum required energy for reproduction        
        repro_energy = 100;
        //set the lifespan for a random number within 1800 frames
        lifespan = Greenfoot.getRandomNumber(900)+900;
        //set health
        health = 100;
        //set starting energy
        energy = 25;
        //set starting size
        siz = (int)(0.2*energy+10.);
        //set att and def to 0
        att = 0;
        def = 0;
        //get image with size variable
        getImage(siz);
        //initialize MyWorld
        MyWorld world;
        
           
    }
    
    /**
     * Act - do whatever the PlantGrass wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // if world isnt initialized
        if(world == null){
            world = (MyWorld) getWorld();
        }
        //run feed 
        feed();
        //run grow
        grow();
        //if amount of algae in the world is less than 800, keep reproducing
            if (algAmount < 800){
           
            reproduce();
        }
        //run age
        age();
    }    
    
    public void feed(){//Increases energy
        //get any algae touching this one
        getIntersectingObjects(Algae.class);
        //make a double equal the number of touching algae
        double neighbourAmount = getIntersectingObjects(Algae.class).size();  
       if (neighbourAmount > 0){//if the amount is bigger than 0, reduce the amount of energy it gets
            energy += 0.5 - (neighbourAmount *0.01) ;
            
            
        }else{ //else get the standard amount
            energy += 0.5;
        }   

    }

       public void grow(){//growth function
        if (siz <= 25){//until size  = 25
            //set size to 20% of energy plus 10
            siz = (int)(0.2*energy+10.);
        }
        //set image siz
        getImage(siz);
    }
    public void getImage(int siz){
        //set image parameters
        GreenfootImage img = new GreenfootImage(siz,siz);
        //set the border color and size
        img.setColor(edge);
        img.fillOval(0-1,0-1,siz-9,siz-9);
        //set the inside color and size
        img.setColor(fill);
        img.fillOval(0,0,siz-11,siz-11);
        //draw the variable
        setImage(img);
    }
    public void reproduce(){
        //check to see if there is enough energy to split
    
        int numKids = (Greenfoot.getRandomNumber(4)+1); //set a random number of children
        //int angle = 360/numKids;
       
        if(energy>=repro_energy){//when energy is bigger than required reproduction energy
         
            for(int i =0; i<numKids; i++){ //make a number of tempkids
                Algae tempKid = new Algae();  //set algae to tempKid
                world.addObject(tempKid,getX(),getY()); //spawn a new tempKid
                mutate(); //mutate the dna 
                
                tempKid.lifespan = newDna[0]; //set the dna
                lifeforms.add(tempKid); //add the new kid to the lifeforms array
                algAmount += numKids;
                tempKid.turn(Greenfoot.getRandomNumber(359)+1);   //make it turn once it respawns
                tempKid.move(Greenfoot.getRandomNumber(40)+20);     //make it move in the previous direction
                if (getX() >= 800 || getY() >=700){//set borders
                    
                    tempKid.move((Greenfoot.getRandomNumber(40)+20)*-1);
                }                 else if (getX() <= 20 ||getY() <= 20){
                    tempKid.move((Greenfoot.getRandomNumber(40)+20)*-1);  
                }
            }
            
            world.addObject(corp, getX(), getY());
            die();//die after reproducing and add corpse
        }
    }

    public void age(){
        //increase age
        age ++;
        //and check to see if past lifespan
            if (AbstOrganism.lifeforms.size() >= 4){ //they will only die from age if theres more than 4 lifeforms
                if(age>= lifespan){// they will only die if they ve lived from 900 to 1800 frames
                    //die and add corpse
                    world.addObject(corp, getX(), getY());
                    die();
                }
            }
    }



    public void move(){

        
        //say("Move not implemented");
    }
    
    
    public void mutate(){
        //send dna of parent organism to be mutated and put new values in array
        newDna = new int[]{this.lifespan,(int)this.repro_energy,this.def};
        Mutate.mutateAlgae(newDna);
    }
}
