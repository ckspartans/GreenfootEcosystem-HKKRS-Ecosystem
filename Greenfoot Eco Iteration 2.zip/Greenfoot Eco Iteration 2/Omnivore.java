import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
//import java.awt.*;
/**
 * Write a description of class Omnivore here.
 * 
 * @author Hector Salermo 
 * @version (a version number or a date)
 */
public class Omnivore extends AbstOrganism
{
    /**
     * Act - do whatever the Omnivore wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    //initialize the newDna
    int []newDna;
    // arrays for target of the omnivore
    public ArrayList <PlantEater> target;
    public ArrayList <Scavenger> target2;
    public ArrayList <Carnivore> target3;
    public ArrayList <Algae> target4;


    //initialize planteater, nearestTarget, AI and Corpse
    public PlantEater PE = new PlantEater();
    public Actor nearestTarg;
    public AI ai = new AI();
    Corpse corp = new Corpse();
    //set border color
    Color edge = new Color(0,0,0);
    //set fill color
    Color fill = new Color(255,140,0);
     //boolean to check tracking
    boolean t = false;
        public Omnivore(){
         //set up mutate variable with desired components       
        newDna = new int[]{(int)this.speed,(int)this.sight,(int)this.repro_energy};
        //set the lifespan for a random number within 1800 frames
        lifespan = lifespan = Greenfoot.getRandomNumber(900)+900;
        //set starting age to 0
        age = 0;
        //minimum required energy for reproduction
        repro_energy = 100;
        //set speed
        speed = 5;
        //set sight
        sight = 100;
        //set health
        health = 100;
        //set energy
        energy = 35.0;
        //set att and def
        att = 7;
        def = 4;
        //initialze world
        MyWorld world = (MyWorld) getWorld();
         

    }
 
     public void getImage(int siz){
        
        //set starting size for image
        GreenfootImage img = new GreenfootImage(siz,siz);
        //set the border color and size
        img.setColor(edge);
        img.fillOval(0-1,0-1,siz-9,siz-9);
        //set the inside color and size
        img.setColor(fill);
        img.fillOval(0,0,siz-11,siz-11);
        //draw the image
        setImage(img); 
    }

    public void act() 
    {
        
        if(world == null){
            world = (MyWorld) getWorld();
        }
        //set target 1 to planteater
        target = (ArrayList) getWorld().getObjects(PlantEater.class);
        //set target 2 to scavenger
        target2 = (ArrayList) getWorld().getObjects(Scavenger.class);
        //set target 3 to carnivore
        target3 = (ArrayList) getWorld().getObjects(Carnivore.class);
        //set target 4 to algae
        target4 = (ArrayList) getWorld().getObjects(Algae.class);
        //if theres a planteater in range then track it
        if (target.size() >0 && target != null){
            ai.trk(this, target,speed, sight);
            t = true;
        }else{
            t = false;
        }
         //if there is a scavenger in range then track
        if(target2.size() >0 && target2 != null){
            ai.trk(this, target2,speed, sight);
            t = true;
        }else{
            t = false;
        }
         //if there is a carnivore in range then track
        if(target3.size() >0 && target3 != null){
            ai.trk(this, target3,speed, sight);
            t = true;
        }else{
            t = false;
        }
        // if there is an algae in range then track
        if (target4.size() >0 && target4 != null){
            ai.trk(this, target4,speed, sight);
            t = true;
        }else{
            t = false;
        }
        //if not tracking, turn and move until it tracks
        if(t == false){
            setRotation(getRotation()+Greenfoot.getRandomNumber(40)-20);
            move(1);
        }
        // if it has a target then feed
        if(target!=null||target2!=null||target3!=null){
           feed();
        }
        //run grow
        grow();
        //run age
        age();
        //run reproduce
        reproduce();
    }
    public void feed(){
        //if theres a planteater, run this for loop
        for(int i = 0; i <target.size(); i++){
            if(MyWorld.getDist(this, target.get(i))<MyWorld.getDist(siz,target.get(i).siz)+5){// if withing attacking distance, run ai.eat
                ai.eat(this, target.get(i));// eat the target
                target = (ArrayList) getWorld().getObjects(PlantEater.class);//reset the target array
            }
            else{
                target.get(i).f = true;
            }
        }
        for(int i = 0; i <target2.size(); i++){
            if(MyWorld.getDist(this, target2.get(i))<MyWorld.getDist(siz,target2.get(i).siz)+5){// if withing attacking distance, run ai.eat
                ai.eat(this, target2.get(i));// eat the target
                target2 = (ArrayList) getWorld().getObjects(Scavenger.class);//reset the target2 array
            }
            else{
                target2.get(i).f = true;
            }
        }
        for(int i = 0; i <target3.size(); i++){
            if(MyWorld.getDist(this, target3.get(i))<MyWorld.getDist(siz,target3.get(i).siz)+5){// if withing attacking distance, run ai.eat
                ai.eat(this, target3.get(i));// eat the target
                target3 = (ArrayList) getWorld().getObjects(Carnivore.class);//reset the target3 array
            }
            else{
                target3.get(i).f = true;
            }
        }
        for(int i = 0; i <target4.size(); i++){
            if(MyWorld.getDist(this, target4.get(i))<10){// if withing attacking distance, eat the algae
                energy += target4.get(i).energy*0.09; //get the target's energy and gain 9% of it
                lifeforms.remove(Algae.class);//remove the algae from lifeforms
                removeTouching(Algae.class);               //remove the algae from the world
                target4.remove(i);//remove the algae from the array
                target4 = (ArrayList) getWorld().getObjects(Algae.class);//reset the target4 array
            }
        }
    }


    public void age(){
        //increase the age
        age ++;
        //decrease the energy
        energy -= 0.01;
        
        if (energy >= 10 || health >= 20){ // if hungry, go faster
            speed = newDna[0]+1;
            
        }else{
            speed = newDna[0]+2;
        }
        //and check to see if past lifespan or below the required energy level
        if(age>= lifespan || energy <= 20){
             world.addObject(corp, getX(), getY());
             die();
             
        
        }
       
    }
    public void mutate(){
        //set new Dna
        newDna = new int[]{(int)this.speed,(int)this.sight,(int)this.repro_energy,(int)health, att, def};
        //mutate with new Dna
        Mutate.mutateScavenger(newDna);
    }
    public void reproduce(){
        int numKids = 2; //set a random number of children
       
            if(energy>repro_energy){//when energy is bigger than required reproduction energy
               
                for(int i =0; i<numKids; i++){ //make a number of tempkids
                Omnivore tempKidC = new Omnivore();  //set algae to tempKid
                mutate();
                tempKidC.speed = newDna[0];
                tempKidC.sight = newDna[1];
                tempKidC.repro_energy = newDna[2];
                tempKidC.health = newDna[3];
                tempKidC.att = newDna[4];
                tempKidC.def = newDna[5];
                if (energy >= repro_energy){
                    world.addObject(tempKidC,getX(),getY()); //spawn a new tempKid
                    lifeforms.add(tempKidC); //add the new kid to the lifeforms array
                    tempKidC.turn(Greenfoot.getRandomNumber(359)+1);   //make it turn once it respawns
                    tempKidC.move(Greenfoot.getRandomNumber(90)+20);     //make it move in the previous direction
                }
            }
            world.addObject(corp, getX(), getY());//die then add a corpse
            die();
        }
    }
    public void grow(){
         if (siz <= 35){//until size  = 35
            //set size to 20% of energy plus 10
            siz = (int)(0.2*energy+25.);
        }
        //set image siz
        getImage(siz);
    }
    
}